// Ghadeer wrote this
var selects = document.getElementsByTagName('select');
for (var i = 0; i < selects.length; i++) {
	selects[i].options[1].selected = true;
}
